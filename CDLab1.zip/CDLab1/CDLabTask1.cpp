#include <iostream>
using namespace std;

int main() {

    char input[100];
    cout << "Enter input: ";
    cin >> input;

    for (int i = 0; input[i] != '\0'; i++) {

    if (input[i] < '0' || input[i] > '9') {

    cout << "not numeric constant." << endl;
    return 0;
}
}
    cout << "numeric constant." << endl;
    return 0;
}

