#include <iostream>
using namespace std;

int main() {
    char input[200];
    cout << "Enter input: ";
    cin.getline(input, 200);


    if (input[0] == '/' && input[1] == '/') {
    cout << "This is a single-line comment." << endl;
}

    else if (input[0] == '/' && input[1] == '*') {
        int i = 2;
        bool foundEnd = false;

        while (input[i] != '\0') {

        if (input[i] == '*' && input[i + 1] == '/') {
        foundEnd = true;

    break;
}
    i++;
}

    if (foundEnd) {
    cout << "This is a multi-line comment." << endl;
}
    else {

    cout << "This looks like a multi-line comment but it's not closed properly." << endl;
}
}
    else {

    cout << "This is not a comment." << endl;
}

    return 0;
}
