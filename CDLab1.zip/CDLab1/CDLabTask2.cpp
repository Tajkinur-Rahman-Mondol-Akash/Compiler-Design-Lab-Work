#include <iostream>
using namespace std;

int main() {
    char input[100];
    cout << "Enter an expression: ";
    cin >> input;

    int count = 1;

    for (int i = 0; input[i] != '\0'; i++) {

    char ch = input[i];
    if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%') {

    cout << "operator" << count << ": " << ch << endl;
    count++;
}
}

    if (count == 1) {
    cout << "No arithmetic operators found." << endl;
}

    return 0;
}
